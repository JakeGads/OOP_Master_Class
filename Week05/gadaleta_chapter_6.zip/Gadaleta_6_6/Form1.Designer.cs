﻿
namespace Gadaleta_6_6
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Vist_Box = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Day_nf = new System.Windows.Forms.NumericUpDown();
            this.Charges_Box = new System.Windows.Forms.GroupBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Final_Box = new System.Windows.Forms.GroupBox();
            this.Total_tf = new System.Windows.Forms.TextBox();
            this.Additional_Fees_tf = new System.Windows.Forms.TextBox();
            this.Stay_Charges_tf = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.Submit_btn = new System.Windows.Forms.Button();
            this.Vist_Box.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Day_nf)).BeginInit();
            this.Charges_Box.SuspendLayout();
            this.Final_Box.SuspendLayout();
            this.SuspendLayout();
            // 
            // Vist_Box
            // 
            this.Vist_Box.Controls.Add(this.label1);
            this.Vist_Box.Controls.Add(this.Day_nf);
            this.Vist_Box.Location = new System.Drawing.Point(13, 13);
            this.Vist_Box.Name = "Vist_Box";
            this.Vist_Box.Size = new System.Drawing.Size(311, 57);
            this.Vist_Box.TabIndex = 0;
            this.Vist_Box.TabStop = false;
            this.Vist_Box.Text = "Visit Duration";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(266, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(39, 19);
            this.label1.TabIndex = 1;
            this.label1.Text = "Days";
            // 
            // Day_nf
            // 
            this.Day_nf.Location = new System.Drawing.Point(7, 23);
            this.Day_nf.Name = "Day_nf";
            this.Day_nf.Size = new System.Drawing.Size(253, 23);
            this.Day_nf.TabIndex = 0;
            // 
            // Charges_Box
            // 
            this.Charges_Box.Controls.Add(this.textBox4);
            this.Charges_Box.Controls.Add(this.textBox3);
            this.Charges_Box.Controls.Add(this.textBox2);
            this.Charges_Box.Controls.Add(this.textBox1);
            this.Charges_Box.Controls.Add(this.label5);
            this.Charges_Box.Controls.Add(this.label4);
            this.Charges_Box.Controls.Add(this.label3);
            this.Charges_Box.Controls.Add(this.label2);
            this.Charges_Box.Location = new System.Drawing.Point(9, 76);
            this.Charges_Box.Name = "Charges_Box";
            this.Charges_Box.Size = new System.Drawing.Size(315, 145);
            this.Charges_Box.TabIndex = 1;
            this.Charges_Box.TabStop = false;
            this.Charges_Box.Text = "Additional Charges";
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(146, 110);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(153, 23);
            this.textBox4.TabIndex = 7;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(146, 81);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(153, 23);
            this.textBox3.TabIndex = 6;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(146, 52);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(153, 23);
            this.textBox2.TabIndex = 5;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(146, 23);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(153, 23);
            this.textBox1.TabIndex = 4;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(54, 113);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(86, 15);
            this.label5.TabIndex = 3;
            this.label5.Text = "Physical Rehab";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(114, 84);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(26, 15);
            this.label4.TabIndex = 2;
            this.label4.Text = "Lab";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(91, 55);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(49, 15);
            this.label3.TabIndex = 1;
            this.label3.Text = "Surgical";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(73, 26);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 15);
            this.label2.TabIndex = 0;
            this.label2.Text = "Medication";
            // 
            // Final_Box
            // 
            this.Final_Box.Controls.Add(this.Total_tf);
            this.Final_Box.Controls.Add(this.Additional_Fees_tf);
            this.Final_Box.Controls.Add(this.Stay_Charges_tf);
            this.Final_Box.Controls.Add(this.label8);
            this.Final_Box.Controls.Add(this.label7);
            this.Final_Box.Controls.Add(this.label6);
            this.Final_Box.Location = new System.Drawing.Point(9, 237);
            this.Final_Box.Name = "Final_Box";
            this.Final_Box.Size = new System.Drawing.Size(315, 136);
            this.Final_Box.TabIndex = 2;
            this.Final_Box.TabStop = false;
            this.Final_Box.Text = "Charges";
            // 
            // Total_tf
            // 
            this.Total_tf.Location = new System.Drawing.Point(146, 90);
            this.Total_tf.Name = "Total_tf";
            this.Total_tf.ReadOnly = true;
            this.Total_tf.Size = new System.Drawing.Size(163, 23);
            this.Total_tf.TabIndex = 5;
            // 
            // Additional_Fees_tf
            // 
            this.Additional_Fees_tf.Location = new System.Drawing.Point(146, 59);
            this.Additional_Fees_tf.Name = "Additional_Fees_tf";
            this.Additional_Fees_tf.ReadOnly = true;
            this.Additional_Fees_tf.Size = new System.Drawing.Size(163, 23);
            this.Additional_Fees_tf.TabIndex = 4;
            // 
            // Stay_Charges_tf
            // 
            this.Stay_Charges_tf.Location = new System.Drawing.Point(146, 30);
            this.Stay_Charges_tf.Name = "Stay_Charges_tf";
            this.Stay_Charges_tf.ReadOnly = true;
            this.Stay_Charges_tf.Size = new System.Drawing.Size(163, 23);
            this.Stay_Charges_tf.TabIndex = 3;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(108, 93);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(32, 15);
            this.label8.TabIndex = 2;
            this.label8.Text = "Total";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(52, 62);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(88, 15);
            this.label7.TabIndex = 1;
            this.label7.Text = "Additional Fees";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(65, 33);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(75, 15);
            this.label6.TabIndex = 0;
            this.label6.Text = "Stay Charges";
            // 
            // Submit_btn
            // 
            this.Submit_btn.Location = new System.Drawing.Point(123, 401);
            this.Submit_btn.Name = "Submit_btn";
            this.Submit_btn.Size = new System.Drawing.Size(75, 23);
            this.Submit_btn.TabIndex = 3;
            this.Submit_btn.Text = "Submit";
            this.Submit_btn.UseVisualStyleBackColor = true;
            this.Submit_btn.Click += new System.EventHandler(this.Submit_btn_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(336, 450);
            this.Controls.Add(this.Submit_btn);
            this.Controls.Add(this.Final_Box);
            this.Controls.Add(this.Charges_Box);
            this.Controls.Add(this.Vist_Box);
            this.Name = "Form1";
            this.Text = "Hospital Charge Calculator";
            this.Vist_Box.ResumeLayout(false);
            this.Vist_Box.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Day_nf)).EndInit();
            this.Charges_Box.ResumeLayout(false);
            this.Charges_Box.PerformLayout();
            this.Final_Box.ResumeLayout(false);
            this.Final_Box.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox Vist_Box;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown Day_nf;
        private System.Windows.Forms.GroupBox Charges_Box;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.GroupBox Final_Box;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox Stay_Charges_tf;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox Total_tf;
        private System.Windows.Forms.TextBox Additional_Fees_tf;
        private System.Windows.Forms.Button Submit_btn;
    }
}

